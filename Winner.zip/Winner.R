Winner=function(var1,var2){
SoccerData=read.csv("C:\\Users\\kgalb\\Downloads\\SoccerData.csv")
attach(SoccerData)
model=lm(X2021ScoreDifference~log(X2018.Average.HomeScore+1)+log(X2018.Average.AwayScore+1)+X2019.Average.HomeScore+X2019.Average.AwayScore)
Wins=fitted.values(model)
comparisontable=cbind(Country, model$fitted.values)
if (var1>var2) print(paste(var1, "wins!")) else if (var2>var1) print(paste(var2, "wins!")) else print("It is a tie")
detach(SoccerData)
}
